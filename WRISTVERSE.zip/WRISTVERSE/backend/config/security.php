<?php
/** WRISTVERSE security/session helpers. */

function startSecureSession(): void {
    if (session_status() === PHP_SESSION_ACTIVE) return;
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

function csrfToken(): string {
    startSecureSession();
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function requireCsrf(): void {
    $provided = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
    $expected = csrfToken();
    if (!$provided || !hash_equals($expected, $provided)) {
        sendError('Invalid or missing CSRF token.', 419);
    }
}

function currentUser(): ?array {
    startSecureSession();
    return $_SESSION['pv_user'] ?? null;
}

function requireLogin(): array {
    $user = currentUser();
    if (!$user) sendError('Authentication required.', 401);
    return $user;
}

function requireAdmin(): array {
    $user = requireLogin();
    if (($user['role'] ?? '') !== 'admin') sendError('Administrator access required.', 403);
    return $user;
}

function setSessionUser(array $row): array {
    startSecureSession();
    $user = [
        'id' => (int)$row['id'],
        'name' => (string)$row['name'],
        'email' => (string)$row['email'],
        'role' => (string)$row['role'],
        'phone' => (string)($row['phone'] ?? ''),
        'city' => (string)($row['city'] ?? ''),
        'address' => (string)($row['address'] ?? ''),
    ];
    $_SESSION['pv_user'] = $user;
    csrfToken();
    return $user;
}

function cleanText($value, int $maxLength = 1000): string {
    $text = trim(strip_tags((string)$value));
    $text = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $text) ?? '';
    if (mb_strlen($text) > $maxLength) $text = mb_substr($text, 0, $maxLength);
    return $text;
}

function isValidDate(string $date): bool {
    $d = DateTime::createFromFormat('Y-m-d', $date);
    return $d && $d->format('Y-m-d') === $date;
}
