<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/security.php';

startSecureSession();
$pdo = getDB();
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

function attachItems(PDO $pdo, array $orders): array {
    if (!$orders) return [];
    $ids = array_map(fn($o)=>(int)$o['id'], $orders);
    $marks = implode(',', array_fill(0,count($ids),'?'));
    $st = $pdo->prepare("SELECT * FROM order_items WHERE order_id IN ($marks) ORDER BY id ASC");
    $st->execute($ids); $by=[];
    foreach($st->fetchAll() as $it) $by[(int)$it['order_id']][]=$it;
    foreach($orders as &$o) $o['items']=$by[(int)$o['id']]??[];
    return $orders;
}

function savePaymentProof(array $file): string {
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return '';
    if (($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) sendError('Payment proof upload failed.');
    if (($file['size'] ?? 0) > 8*1024*1024) sendError('Payment proof must be under 8MB.');
    $finfo=new finfo(FILEINFO_MIME_TYPE); $mime=$finfo->file($file['tmp_name']);
    $exts=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
    if(!isset($exts[$mime])) sendError('Payment proof must be JPG, PNG or WEBP.');
    $base=realpath(__DIR__.'/../../watches'); if(!$base) sendError('Store upload directory not found.',500);
    $dir=$base.'/uploads/payment-proofs'; if(!is_dir($dir)&&!mkdir($dir,0775,true)) sendError('Could not create payment proof folder.',500);
    $name='proof_'.date('Ymd_His').'_'.bin2hex(random_bytes(6)).'.'.$exts[$mime];
    if(!move_uploaded_file($file['tmp_name'],$dir.'/'.$name)) sendError('Could not save payment proof.',500);
    return 'uploads/payment-proofs/'.$name;
}

function publicOrder(array $o): array {
    $name=trim((string)($o['customer_name']??''));
    if($name!==''){
        $parts=preg_split('/\s+/', $name); $masked=[];
        foreach($parts as $p) $masked[]=mb_substr($p,0,1).str_repeat('*',max(1,mb_strlen($p)-1));
        $name=implode(' ',$masked);
    }
    return [
        'order_number'=>$o['order_number'], 'customer_name'=>$name, 'city'=>$o['city'],
        'address'=>'Hidden for privacy', 'payment_method'=>$o['payment_method'],
        'subtotal'=>$o['subtotal'], 'discount'=>$o['discount'], 'shipping'=>$o['shipping'], 'total'=>$o['total'],
        'status'=>$o['status'], 'payment_status'=>$o['payment_status'], 'tracking_number'=>$o['tracking_number'],
        'tracking_url'=>$o['tracking_url'], 'created_at'=>$o['created_at'], 'items'=>$o['items']??[]
    ];
}

try {
    if ($method === 'GET') {
        $tracking = trim((string)($_GET['tracking'] ?? $_GET['order_number'] ?? ''));
        if ($tracking !== '') {
            $st=$pdo->prepare('SELECT * FROM orders WHERE order_number=? OR tracking_number=? LIMIT 1');
            $st->execute([$tracking,$tracking]); $o=$st->fetch(); if(!$o)sendError('No order found with that order/tracking number.',404);
            $o=attachItems($pdo,[$o])[0];
            $user=currentUser();
            $canSeeFull=$user && (($user['role']??'')==='admin' || (int)($o['user_id']??0)===(int)$user['id'] || strtolower((string)$o['email'])===strtolower((string)$user['email']));
            sendResponse(['success'=>true,'data'=>$canSeeFull?$o:publicOrder($o)]);
        }

        if (isset($_GET['mine']) && $_GET['mine']==='1') {
            $user=requireLogin();
            $st=$pdo->prepare('SELECT * FROM orders WHERE user_id=? OR (email<>\'\' AND LOWER(email)=LOWER(?)) ORDER BY id DESC');
            $st->execute([$user['id'],$user['email']]);
            sendResponse(['success'=>true,'data'=>attachItems($pdo,$st->fetchAll())]);
        }

        requireAdmin();
        $orders=$pdo->query('SELECT * FROM orders ORDER BY id DESC')->fetchAll();
        sendResponse(['success'=>true,'data'=>attachItems($pdo,$orders)]);
    }

    if ($method === 'POST') {
        $body=getRequestBody(); $action=$_GET['action'] ?? ($body['action']??'');
        if ($action === 'status') {
            requireAdmin(); requireCsrf();
            $id=(int)($body['id']??0); $status=trim((string)($body['status']??''));
            $tracking=trim((string)($body['tracking_number']??'')); $url=trim((string)($body['tracking_url']??''));
            $allowed=['Pending','Confirmed','Processing','Dispatched','Delivered','Cancelled'];
            if(!$id||!in_array($status,$allowed,true)) sendError('Valid order ID/status required.');
            $pdo->beginTransaction();
            $st=$pdo->prepare('SELECT status FROM orders WHERE id=? FOR UPDATE');$st->execute([$id]);$old=$st->fetchColumn();if($old===false)throw new RuntimeException('Order not found.');
            if($old!=='Cancelled' && $status==='Cancelled'){
                $items=$pdo->prepare('SELECT product_id,qty FROM order_items WHERE order_id=?');$items->execute([$id]);
                $up=$pdo->prepare('UPDATE products SET stock=stock+? WHERE id=?');
                foreach($items->fetchAll() as $it) if($it['product_id'])$up->execute([(int)$it['qty'],(int)$it['product_id']]);
            } elseif($old==='Cancelled' && $status!=='Cancelled'){
                $items=$pdo->prepare('SELECT product_id,qty FROM order_items WHERE order_id=?');$items->execute([$id]);
                $check=$pdo->prepare('SELECT stock FROM products WHERE id=? FOR UPDATE');$deduct=$pdo->prepare('UPDATE products SET stock=stock-? WHERE id=?');
                foreach($items->fetchAll() as $it){ if(!$it['product_id'])continue; $check->execute([(int)$it['product_id']]);$stock=(int)$check->fetchColumn();if($stock<(int)$it['qty'])throw new RuntimeException('Not enough stock to reopen this cancelled order.');$deduct->execute([(int)$it['qty'],(int)$it['product_id']]); }
            }
            $st=$pdo->prepare('UPDATE orders SET status=?,tracking_number=?,tracking_url=? WHERE id=?');$st->execute([$status,$tracking,$url,$id]);
            $pdo->commit(); sendResponse(['success'=>true,'message'=>'Order updated successfully']);
        }

        // Public/customer order creation. CSRF token is issued to every browser session.
        requireCsrf();
        $name=cleanText($body['customer_name']??'',255); $phone=cleanText($body['phone']??'',50);
        $email=strtolower(trim((string)($body['email']??''))); $address=cleanText($body['address']??'',2000);
        $city=cleanText($body['city']??'',100); $postal=cleanText($body['postal_code']??'',30); $notes=cleanText($body['notes']??'',2000);
        $methodPay=cleanText($body['payment_method']??'cod',20); $tid=cleanText($body['transaction_id']??'',150);
        $rawItems=$body['items']??[]; if(is_string($rawItems))$rawItems=json_decode($rawItems,true)?:[];
        if($name===''||$phone===''||$address===''||$city==='')sendError('Name, phone, address and city are required.');
        if($email!==''&&!filter_var($email,FILTER_VALIDATE_EMAIL))sendError('Please enter a valid email address.');
        if(!in_array($methodPay,['cod','easypaisa','jazzcash'],true))sendError('Unsupported payment method.');
        if(!is_array($rawItems)||count($rawItems)===0)sendError('Cart is empty.');
        if(count($rawItems)>50)sendError('Too many order items.');

        $proof='';
        if(!empty($_FILES['payment_proof'])) $proof=savePaymentProof($_FILES['payment_proof']);
        if($methodPay!=='cod' && $proof==='')sendError('Please attach payment proof for Easypaisa/JazzCash.');

        $cfgRow=$pdo->query("SELECT setting_value FROM settings WHERE setting_key='store_config' LIMIT 1")->fetchColumn();
        $cfg=$cfgRow ? (json_decode($cfgRow,true)?:[]) : [];
        $shipping=max(0,(float)($cfg['shipping_charge']??250)); $discountPct=min(100,max(0,(float)($cfg['discount_percent']??5)));
        $user=currentUser(); $userId=$user ? (int)$user['id'] : null;

        $pdo->beginTransaction();
        $validated=[]; $subtotal=0.0;
        $sel=$pdo->prepare('SELECT id,name,price,stock,active FROM products WHERE id=? FOR UPDATE');
        foreach($rawItems as $it){
            $pid=(int)($it['id']??$it['product_id']??0); $qty=(int)($it['qty']??0);
            if(!$pid||$qty<1||$qty>100)throw new RuntimeException('Invalid product/quantity in cart.');
            $sel->execute([$pid]); $p=$sel->fetch(); if(!$p||!(int)$p['active'])throw new RuntimeException('A product in your cart is no longer available.');
            if((int)$p['stock']<$qty)throw new RuntimeException($p['name'].' has only '.$p['stock'].' unit(s) available.');
            $price=(float)$p['price']; $line=round($price*$qty,2); $subtotal+=$line;
            $validated[]=['id'=>(int)$p['id'],'name'=>$p['name'],'price'=>$price,'qty'=>$qty,'line'=>$line];
        }
        $subtotal=round($subtotal,2); $discount=($methodPay==='cod')?0:round($subtotal*($discountPct/100),2); $total=round(max(0,$subtotal-$discount+$shipping),2);
        $orderNumber='WV-'.date('ymd').'-'.strtoupper(bin2hex(random_bytes(3)));
        $payStatus=$methodPay==='cod'?'Unpaid':'Awaiting Confirmation';
        $st=$pdo->prepare("INSERT INTO orders(order_number,user_id,customer_name,phone,email,address,city,postal_code,notes,payment_method,payment_proof,transaction_id,subtotal,discount,shipping,total,status,payment_status,tracking_number,tracking_url) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, 'Pending',?,'','')");
        $st->execute([$orderNumber,$userId,$name,$phone,$email,$address,$city,$postal,$notes,$methodPay,$proof,$tid,$subtotal,$discount,$shipping,$total,$payStatus]);
        $orderId=(int)$pdo->lastInsertId();
        $ins=$pdo->prepare('INSERT INTO order_items(order_id,product_id,name,price,qty,line) VALUES(?,?,?,?,?,?)');
        $deduct=$pdo->prepare('UPDATE products SET stock=stock-? WHERE id=?');
        foreach($validated as $it){$ins->execute([$orderId,$it['id'],$it['name'],$it['price'],$it['qty'],$it['line']]);$deduct->execute([$it['qty'],$it['id']]);}
        $pdo->commit();
        $o=$pdo->prepare('SELECT * FROM orders WHERE id=?');$o->execute([$orderId]);$full=attachItems($pdo,[$o->fetch()])[0];
        sendResponse(['success'=>true,'message'=>'Order placed successfully','data'=>$full],201);
    }
    sendError('Method not allowed.',405);
} catch(Throwable $e) {
    if($pdo->inTransaction())$pdo->rollBack();
    $msg=$e instanceof RuntimeException ? $e->getMessage() : 'Order request failed.';
    sendError($msg, $e instanceof RuntimeException ? 400 : 500);
}
