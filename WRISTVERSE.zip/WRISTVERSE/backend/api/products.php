<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/security.php';

startSecureSession();
$pdo = getDB();
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

function saveProductUpload(array $file): string {
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return '';
    if (($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) sendError('Product image upload failed.');
    if (($file['size'] ?? 0) > 8 * 1024 * 1024) sendError('Product image must be under 8MB.');
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);
    $exts = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp','image/gif'=>'gif'];
    if (!isset($exts[$mime])) sendError('Only JPG, PNG, WEBP or GIF images are allowed.');
    $dir = realpath(__DIR__ . '/../../watches') . '/uploads/products';
    if (!is_dir($dir) && !mkdir($dir, 0775, true)) sendError('Could not create product upload folder.', 500);
    $name = 'product_' . bin2hex(random_bytes(8)) . '.' . $exts[$mime];
    if (!move_uploaded_file($file['tmp_name'], $dir . '/' . $name)) sendError('Could not save product image.', 500);
    return 'uploads/products/' . $name;
}

try {
    if ($method === 'GET') {
        $all = isset($_GET['all']) && $_GET['all'] === '1';
        if ($all) requireAdmin();
        if (isset($_GET['id'])) {
            $id = (int)$_GET['id'];
            $sql = $all ? 'SELECT * FROM products WHERE id=?' : 'SELECT * FROM products WHERE id=? AND active=1';
            $stmt = $pdo->prepare($sql); $stmt->execute([$id]);
            $p = $stmt->fetch();
            if (!$p) sendError('Product not found.', 404);
            sendResponse(['success'=>true,'data'=>$p]);
        }
        $sql = $all ? 'SELECT * FROM products ORDER BY id ASC' : 'SELECT * FROM products WHERE active=1 ORDER BY id ASC';
        sendResponse(['success'=>true,'data'=>$pdo->query($sql)->fetchAll()]);
    }

    if ($method === 'POST') {
        requireAdmin(); requireCsrf();
        $body = getRequestBody();
        $action = $_GET['action'] ?? ($body['action'] ?? '');
        if ($action === 'toggle') {
            $id = (int)($body['id'] ?? 0); if (!$id) sendError('Valid product ID required.');
            $st = $pdo->prepare('UPDATE products SET active=IF(active=1,0,1) WHERE id=?'); $st->execute([$id]);
            sendResponse(['success'=>true,'message'=>'Product status updated.']);
        }

        $id = (int)($body['id'] ?? 0);
        $existing = null;
        if ($id) {
            $st = $pdo->prepare('SELECT * FROM products WHERE id=?'); $st->execute([$id]); $existing = $st->fetch();
            if (!$existing) sendError('Product not found.', 404);
        }
        $pick = function($key, $default = null) use ($body, $existing) {
            return array_key_exists($key, $body) ? $body[$key] : ($existing[$key] ?? $default);
        };
        $name = cleanText($pick('name',''), 255);
        $description = cleanText($pick('description',''), 5000);
        $category = cleanText($pick('category','Smart Watches'), 100);
        $price = (float)$pick('price',0);
        $cost = max(0, (float)$pick('cost_price',0));
        $stock = max(0, (int)$pick('stock',0));
        $image = trim((string)$pick('image',''));
        $featured = !empty($pick('featured',0)) ? 1 : 0;
        $active = (int)$pick('active',1) ? 1 : 0;
        if (!empty($_FILES['image_file'])) {
            $uploaded = saveProductUpload($_FILES['image_file']);
            if ($uploaded) $image = $uploaded;
        }
        if ($name === '' || $price <= 0) sendError('Product name and valid price are required.');

        if ($id) {
            $st = $pdo->prepare('UPDATE products SET name=?,description=?,category=?,price=?,cost_price=?,stock=?,image=?,featured=?,active=? WHERE id=?');
            $st->execute([$name,$description,$category,$price,$cost,$stock,$image,$featured,$active,$id]);
        } else {
            $st = $pdo->prepare('INSERT INTO products (name,description,category,price,cost_price,stock,image,featured,active) VALUES (?,?,?,?,?,?,?,?,?)');
            $st->execute([$name,$description,$category,$price,$cost,$stock,$image,$featured,$active]);
            $id = (int)$pdo->lastInsertId();
        }
        $st = $pdo->prepare('SELECT * FROM products WHERE id=?'); $st->execute([$id]);
        sendResponse(['success'=>true,'message'=>'Product saved successfully','data'=>$st->fetch()], $existing ? 200 : 201);
    }

    if ($method === 'DELETE') {
        requireAdmin(); requireCsrf();
        $id = (int)($_GET['id'] ?? 0); if (!$id) sendError('Valid product ID required.');
        $st = $pdo->prepare('DELETE FROM products WHERE id=?'); $st->execute([$id]);
        sendResponse(['success'=>true,'message'=>'Product deleted successfully']);
    }
    sendError('Method not allowed.', 405);
} catch (Throwable $e) {
    sendError('Product request failed: ' . $e->getMessage(), 500);
}
