<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/security.php';
startSecureSession(); $pdo=getDB(); $method=$_SERVER['REQUEST_METHOD'] ?? 'GET';
try {
    requireAdmin();
    if($method==='GET') sendResponse(['success'=>true,'data'=>$pdo->query('SELECT * FROM expenses ORDER BY expense_date DESC,id DESC')->fetchAll()]);
    if($method==='POST'){
        requireCsrf(); $b=getRequestBody(); $label=cleanText($b['label']??'',255); $amount=(float)($b['amount']??0); $date=trim((string)($b['expense_date']??date('Y-m-d')));
        if($label===''||$amount<=0) sendError('Label and positive amount are required.');
        if(!isValidDate($date)) sendError('Valid expense date is required.');
        $st=$pdo->prepare('INSERT INTO expenses(label,amount,expense_date) VALUES(?,?,?)'); $st->execute([$label,$amount,$date]);
        $id=(int)$pdo->lastInsertId(); $st=$pdo->prepare('SELECT * FROM expenses WHERE id=?');$st->execute([$id]);
        sendResponse(['success'=>true,'message'=>'Expense added successfully','data'=>$st->fetch()],201);
    }
    if($method==='DELETE'){
        requireCsrf(); $id=(int)($_GET['id']??0); if(!$id)sendError('Valid expense ID required.');
        $st=$pdo->prepare('DELETE FROM expenses WHERE id=?');$st->execute([$id]);sendResponse(['success'=>true,'message'=>'Expense deleted']);
    }
    sendError('Method not allowed.',405);
}catch(Throwable $e){sendError('Expense request failed.',500);}
