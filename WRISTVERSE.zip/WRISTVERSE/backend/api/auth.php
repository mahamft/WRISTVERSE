<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/security.php';

startSecureSession();
$pdo = getDB();
$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';

try {
    $action = $_GET['action'] ?? 'me';

    if ($method === 'GET' && $action === 'me') {
        sendResponse(['success' => true, 'user' => currentUser(), 'csrf_token' => csrfToken()]);
    }

    if ($method === 'GET' && $action === 'users') {
        requireAdmin();
        $stmt = $pdo->query("SELECT id,name,email,role,phone,city,address,created_at FROM users WHERE role='customer' ORDER BY id DESC");
        sendResponse(['success' => true, 'data' => $stmt->fetchAll()]);
    }

    if ($method === 'POST') {
        $body = getRequestBody();
        $action = $_GET['action'] ?? ($body['action'] ?? 'login');

        if ($action === 'login') {
            requireCsrf();
            $email = strtolower(trim((string)($body['email'] ?? '')));
            $pass = (string)($body['password'] ?? '');
            if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $pass === '') sendError('Valid email and password are required.');

            $stmt = $pdo->prepare('SELECT id,name,email,password,role,phone,city,address FROM users WHERE LOWER(email)=LOWER(?) LIMIT 1');
            $stmt->execute([$email]);
            $u = $stmt->fetch();
            if (!$u) sendError('Invalid email or password.', 401);

            $valid = password_verify($pass, (string)$u['password']);
            // Safe one-time migration for old plaintext database versions.
            if (!$valid && hash_equals((string)$u['password'], $pass)) {
                $valid = true;
                $hash = password_hash($pass, PASSWORD_DEFAULT);
                $up = $pdo->prepare('UPDATE users SET password=? WHERE id=?');
                $up->execute([$hash, $u['id']]);
            }
            if (!$valid) sendError('Invalid email or password.', 401);

            session_regenerate_id(true);
            $user = setSessionUser($u);
            sendResponse(['success' => true, 'message' => 'Login successful', 'user' => $user, 'csrf_token' => csrfToken()]);
        }

        if ($action === 'register') {
            requireCsrf();
            $name = cleanText($body['name'] ?? '', 255);
            $email = strtolower(trim((string)($body['email'] ?? '')));
            $pass = (string)($body['password'] ?? '');
            if (mb_strlen($name) < 2) sendError('Please enter your full name.');
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) sendError('Please enter a valid email address.');
            if (strlen($pass) < 8) sendError('Password must be at least 8 characters long.');

            $check = $pdo->prepare('SELECT id FROM users WHERE LOWER(email)=LOWER(?) LIMIT 1');
            $check->execute([$email]);
            if ($check->fetch()) sendError('An account with that email already exists.', 409);

            $hash = password_hash($pass, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (name,email,password,role) VALUES (?,?,?,'customer')");
            $stmt->execute([$name, $email, $hash]);
            $id = (int)$pdo->lastInsertId();
            session_regenerate_id(true);
            $user = setSessionUser(['id'=>$id,'name'=>$name,'email'=>$email,'role'=>'customer','phone'=>'','city'=>'','address'=>'']);
            sendResponse(['success' => true, 'message' => 'Account registered successfully', 'user' => $user, 'csrf_token' => csrfToken()], 201);
        }

        if ($action === 'profile') {
            $user = requireLogin();
            requireCsrf();
            $name = cleanText($body['name'] ?? '', 255);
            $phone = cleanText($body['phone'] ?? '', 50);
            $city = cleanText($body['city'] ?? '', 100);
            $address = cleanText($body['address'] ?? '', 2000);
            if (mb_strlen($name) < 2) sendError('Name is required.');
            $stmt = $pdo->prepare('UPDATE users SET name=?,phone=?,city=?,address=? WHERE id=?');
            $stmt->execute([$name,$phone,$city,$address,$user['id']]);
            $fresh = $pdo->prepare('SELECT id,name,email,role,phone,city,address FROM users WHERE id=?');
            $fresh->execute([$user['id']]);
            $updated = setSessionUser($fresh->fetch());
            sendResponse(['success'=>true,'message'=>'Profile updated','user'=>$updated,'csrf_token'=>csrfToken()]);
        }

        if ($action === 'change_password') {
            $user = requireLogin();
            requireCsrf();
            $current = (string)($body['current_password'] ?? '');
            $new = (string)($body['new_password'] ?? '');
            if (strlen($new) < 8) sendError('New password must be at least 8 characters long.');
            $st = $pdo->prepare('SELECT password FROM users WHERE id=? LIMIT 1');
            $st->execute([$user['id']]);
            $hash = (string)$st->fetchColumn();
            if (!$hash || !password_verify($current, $hash)) sendError('Current password is incorrect.', 401);
            $newHash = password_hash($new, PASSWORD_DEFAULT);
            $up = $pdo->prepare('UPDATE users SET password=? WHERE id=?');
            $up->execute([$newHash, $user['id']]);
            session_regenerate_id(true);
            sendResponse(['success'=>true,'message'=>'Password changed successfully','csrf_token'=>csrfToken()]);
        }

        if ($action === 'logout') {
            requireCsrf();
            $_SESSION = [];
            if (ini_get('session.use_cookies')) {
                $p = session_get_cookie_params();
                setcookie(session_name(), '', time()-42000, $p['path'], $p['domain'] ?? '', $p['secure'], $p['httponly']);
            }
            session_destroy();
            sendResponse(['success'=>true,'message'=>'Logged out successfully']);
        }
    }

    sendError('Unsupported request.', 405);
} catch (Throwable $e) {
    sendError('Authentication request failed.', 500);
}
