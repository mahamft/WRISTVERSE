<?php
require_once __DIR__ . '/../config/cors.php';
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/security.php';
startSecureSession(); $pdo=getDB(); $method=$_SERVER['REQUEST_METHOD'] ?? 'GET';
try {
    if ($method==='GET') {
        $st=$pdo->prepare("SELECT setting_value FROM settings WHERE setting_key='store_config' LIMIT 1"); $st->execute(); $row=$st->fetch();
        sendResponse(['success'=>true,'data'=>$row ? (json_decode($row['setting_value'],true) ?: []) : []]);
    }
    if ($method==='POST') {
        requireAdmin(); requireCsrf(); $b=getRequestBody();
        $allowed=['store_name','support_email','store_phone','whatsapp_number','easypaisa_number','jazzcash_number','shipping_charge','discount_percent'];
        $clean=[]; foreach($allowed as $k){ if(array_key_exists($k,$b)) $clean[$k]=$b[$k]; }
        $clean['shipping_charge']=max(0,(float)($clean['shipping_charge'] ?? 250));
        $clean['discount_percent']=min(100,max(0,(float)($clean['discount_percent'] ?? 5)));
        $json=json_encode($clean,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);
        $st=$pdo->prepare("INSERT INTO settings(setting_key,setting_value) VALUES('store_config',?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)"); $st->execute([$json]);
        sendResponse(['success'=>true,'message'=>'Settings saved successfully','data'=>$clean]);
    }
    sendError('Method not allowed.',405);
} catch(Throwable $e){ sendError('Settings request failed.',500); }
