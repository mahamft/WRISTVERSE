<?php
/** Non-destructive XAMPP installer/migrator for WRISTVERSE. */
require_once __DIR__ . '/config/db.php';
$isCli = PHP_SAPI === 'cli';

function out(string $msg, bool $ok = true): void {
    global $isCli;
    if ($isCli) { echo ($ok ? '[OK] ' : '[FAIL] ') . $msg . PHP_EOL; return; }
    $bg = $ok ? '#152b1b' : '#381616'; $fg = $ok ? '#4ade80' : '#f87171';
    echo '<div style="margin:8px 0;padding:10px 14px;border-radius:6px;font-family:monospace;background:' . $bg . ';color:' . $fg . '">' . htmlspecialchars($msg) . '</div>';
}

if (!$isCli) {
    echo '<!doctype html><meta charset="utf-8"><title>WRISTVERSE Installer</title><body style="background:#0b0f17;color:#e2e8f0;font-family:system-ui;padding:40px;max-width:900px;margin:auto"><h1 style="color:#00e5ff">WRISTVERSE MySQL Setup</h1><p>This installer is non-destructive: it creates missing tables/columns and keeps existing orders/customers.</p>';
}

try {
    $server = new PDO('mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';charset=utf8mb4', DB_USER, DB_PASS, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $server->exec('CREATE DATABASE IF NOT EXISTS `' . DB_NAME . '` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
    $server->exec('USE `' . DB_NAME . '`');
    out('Connected to MySQL and verified database `' . DB_NAME . '`.');

    $sql = file_get_contents(__DIR__ . '/../database.sql');
    if ($sql === false) throw new RuntimeException('database.sql not found.');
    $server->exec($sql);
    out('Base schema and seed records verified.');

    // Migrate older ZIP versions without deleting data.
    $migrations = [
        "ALTER TABLE users ADD COLUMN phone VARCHAR(50) NOT NULL DEFAULT '' AFTER role",
        "ALTER TABLE users ADD COLUMN city VARCHAR(100) NOT NULL DEFAULT '' AFTER phone",
        "ALTER TABLE users ADD COLUMN address TEXT NULL AFTER city",
        "ALTER TABLE users ADD COLUMN updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER created_at",
        "ALTER TABLE orders ADD COLUMN user_id INT UNSIGNED NULL AFTER order_number",
        "ALTER TABLE orders ADD COLUMN postal_code VARCHAR(30) NOT NULL DEFAULT '' AFTER city",
        "ALTER TABLE orders ADD COLUMN notes TEXT NULL AFTER postal_code",
        "ALTER TABLE orders ADD COLUMN payment_proof VARCHAR(500) NOT NULL DEFAULT '' AFTER payment_method",
        "ALTER TABLE orders ADD COLUMN transaction_id VARCHAR(150) NOT NULL DEFAULT '' AFTER payment_proof",
        "ALTER TABLE orders ADD COLUMN updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER created_at",
        "ALTER TABLE products MODIFY image VARCHAR(500) NULL",
    ];
    foreach ($migrations as $m) {
        try { $server->exec($m); } catch (PDOException $e) {
            // Duplicate-column / already migrated errors are safe to ignore.
            if (!in_array((int)($e->errorInfo[1] ?? 0), [1060, 1061, 1826], true)) throw $e;
        }
    }

    // Hash legacy plaintext admin/customer passwords when found.
    $rows = $server->query('SELECT id,password FROM users')->fetchAll(PDO::FETCH_ASSOC);
    $upd = $server->prepare('UPDATE users SET password=? WHERE id=?');
    foreach ($rows as $r) {
        if (!str_starts_with((string)$r['password'], '$2y$') && !str_starts_with((string)$r['password'], '$argon2')) {
            $upd->execute([password_hash((string)$r['password'], PASSWORD_DEFAULT), $r['id']]);
        }
    }
    out('Legacy schema/password migration completed.');

    $count = (int)$server->query('SELECT COUNT(*) FROM products')->fetchColumn();
    out("Ready: {$count} products currently in MySQL.");
    if (!$isCli) echo '<p><a style="color:#00e5ff;font-weight:700" href="../watches/index.php">Open storefront →</a> &nbsp; <a style="color:#00e5ff" href="../watches/admin/login.php">Admin login →</a></p>';
} catch (Throwable $e) {
    out($e->getMessage(), false);
}
if (!$isCli) echo '</body>';
