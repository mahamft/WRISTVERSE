<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="assets/images/wristverse-emblem.png">
    <title>WRISTVERSE | Premium Watches</title>
    <meta name="description" content="WRISTVERSE premium watches and smart wearables for timeless everyday style.">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css">
    <style>
        .product-card {
            border-radius: 8px;
            overflow: hidden;
            display: flex;
            flex-direction: column;
        }
        .product-card .product-art {
            position: relative;
            display: block;
            width: 100%;
            height: 260px;
            overflow: hidden;
            background: #090807;
            border-radius: 0;
            text-decoration: none;
            margin: 0;
            padding: 0;
            border-bottom: 1px solid rgba(215, 173, 91, 0.18);
        }
        .product-card .product-image {
            position: relative;
            z-index: 1;
            display: block;
            width: 100%;
            height: 100%;
            object-fit: cover;
            object-position: center;
            padding: 0;
            margin: 0;
            border-radius: 0;
            transition: transform .4s cubic-bezier(0.16, 1, 0.3, 1);
        }
        .product-card:hover .product-image {
            transform: scale(1.08);
        }
        .product-card .product-placeholder {
            position: relative;
            z-index: 1;
            margin: 50px auto;
        }
        .product-card .product-badge {
            position: absolute;
            top: 12px;
            left: 12px;
            z-index: 3;
            background: rgba(10, 9, 8, 0.82);
            backdrop-filter: blur(8px);
            border: 1px solid rgba(215, 173, 91, 0.35);
            color: #d7ad5b;
            font-size: 8px;
            letter-spacing: .12em;
            padding: 5px 10px;
            border-radius: 30px;
        }
        .product-card .product-info {
            display: flex;
            flex-direction: column;
            flex-grow: 1;
        }
        .product-card .product-info button {
            margin-top: auto;
        }
        .hero-section {
            position: relative;
            overflow: hidden;
            background: #060504;
        }
        .hero-bg-layer {
            position: absolute;
            inset: 0;
            background: 
                linear-gradient(90deg, rgba(6, 5, 4, 0.9) 0%, rgba(6, 5, 4, 0.65) 50%, rgba(6, 5, 4, 0.45) 100%),
                radial-gradient(ellipse at 80% 35%, rgba(215, 173, 91, 0.16), transparent 60%),
                url('assets/images/page-hero-bg.jpg') center right / cover no-repeat;
            z-index: 0;
            opacity: 0.9;
            animation: heroBgZoom 24s ease-in-out infinite alternate;
            pointer-events: none;
        }
        @keyframes heroBgZoom {
            0% { transform: scale(1); }
            100% { transform: scale(1.05); }
        }
        .hero-orb {
            display: none !important;
        }
        .hero-grid {
            grid-template-columns: 1fr;
            gap: 0;
            padding-top: 90px;
            padding-bottom: 90px;
        }
        .hero-copy {
            max-width: 680px;
        }
        .hero-visual {
            display: flex;
            flex-wrap: wrap;
            gap: 14px;
            margin-top: 28px;
        }
        .hero-visual .floating-tag {
            position: static;
        }
        @media (max-width: 767px) {
            .hero-grid {
                padding-top: 55px;
                padding-bottom: 50px;
            }
            .hero-visual {
                justify-content: center;
            }
        }
    </style>
</head>
<body>
<div class="topline"></div>
<nav class="navbar navbar-expand-lg navbar-dark pv-nav sticky-top">
    <div class="container">
        <a class='navbar-brand brand brand-image' href='index.php'><img src="assets/images/wristverse-wordmark.png?v=2" alt="WRISTVERSE"></a>
        <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#pvNav" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="pvNav">
            <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-3">
                <li class="nav-item"><a class='nav-link active' href='index.php'>Home</a></li>
                <li class="nav-item"><a class='nav-link' href='shop.php'>Shop</a></li>
                <li class="nav-item"><a class='nav-link' href='track-order.php'>Track Order</a></li>
                <li class="nav-item"><a class='nav-link' href='about.php'>About</a></li>
                <li class="nav-item"><a class='nav-link' href='contact.php'>Contact</a></li>
                <li class="nav-item">
                    <a class='nav-link cart-link' href='cart.php'>
                        Cart <span class="cart-count">0</span>
                    </a>
                </li>
                <li class="nav-item" id="navAuthSlot">
                    <a class='nav-link' href='account/login.php'>Login</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<main>
    <section class="hero-section">
        <div class="hero-bg-layer"></div>
        <div class="hero-orb orb-one"></div>
        <div class="hero-orb orb-two"></div>

        <div class="container hero-grid">
            <div class="hero-copy reveal">
                <div class="eyebrow">
                    <span class="pulse-dot"></span>
                    WRISTVERSE PREMIUM COLLECTION
                </div>

                <h1>TIME BEYOND<br><span class="gradient-text">LIMITS.</span></h1>
                <h2>Smart Watches. Smarter Living.</h2>

                <p>
                    Discover premium smart watches and wearables designed
                    for style, performance and everyday life.
                </p>

                <div class="d-flex flex-wrap gap-3 mt-4">
                    <a class='btn btn-neon' href='shop.php'>
                        Shop Collection <span>→</span>
                    </a>
                    <a class="btn btn-outline-glow" href="#features">
                        Explore Features
                    </a>
                </div>

                <div class="hero-points">
                    <span>✦ Smart Tracking</span>
                    <span>✦ Health Insights</span>
                    <span>✦ All-Day Battery</span>
                </div>
            </div>

            <div class="hero-visual reveal">
                <div class="floating-tag tag-top">
                    <span class="tag-icon">✧</span>
                    <span>
                        <b>Premium Design</b>
                        <small>Built for your wrist</small>
                    </span>
                </div>
                <div class="floating-tag tag-bottom">
                    <span class="tag-icon">ϟ</span>
                    <span>
                        <b>Smart Health</b>
                        <small>Track every beat.</small>
                    </span>
                </div>
            </div>
        </div>
        <div class="hero-bottom-line"></div>
    </section>

    <section class="benefits">
        <div class="container benefits-grid">
            <div>
                <span class="benefit-icon">⚡</span>
                <span><b>Fast Express Delivery</b><small>24-48h dispatch via TCS Courier</small></span>
            </div>
            <div>
                <span class="benefit-icon">⌁</span>
                <span><b>Instant Checkout</b><small>Smooth order processing</small></span>
            </div>
            <div>
                <span class="benefit-icon">ϟ</span>
                <span><b>Flexible Payments</b><small>COD, Easypaisa &amp; JazzCash</small></span>
            </div>
            <div>
                <span class="benefit-icon">◎</span>
                <span><b>Customer Support</b><small>WhatsApp and phone direct support</small></span>
            </div>
        </div>
    </section>

    <section class="section-pad" id="products">
        <div class="container">
            <div class="section-heading">
                <div>
                    <div class="eyebrow">THE COLLECTION</div>
                    <h2>Featured <span class="gradient-text">Products</span></h2>
                    <p>Explore our premium smart watch collection.</p>
                </div>
                <a class='text-link' href='shop.php'>View all products ↗</a>
            </div>

            <div class="row g-4" id="featuredGrid">
                <!-- Dynamically rendered by store.js -->
            </div>
        </div>
    </section>

    <section class="feature-band" id="features">
        <div class="container feature-inner">
            <div>
                <div class="eyebrow">WHY WRISTVERSE</div>
                <h2>Designed for your<br><span class="gradient-text">everyday rhythm.</span></h2>
                <p>Clean design, dependable support and a smooth shopping experience—from browsing to delivery.</p>
            </div>
            <div class="feature-cards">
                <div class="feature-tile">
                    <span>ϟ</span>
                    <h3>Modern Design</h3>
                    <p>Premium dark interface with electric-cyan accents.</p>
                </div>
                <div class="feature-tile">
                    <span>◈</span>
                    <h3>Easy Checkout</h3>
                    <p>Cart, shipping details and instant WhatsApp confirmation.</p>
                </div>
                <div class="feature-tile">
                    <span>◎</span>
                    <h3>Helpful Support</h3>
                    <p>Direct assistance via WhatsApp and helpline.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="section-pad payment-strip">
        <div class="container">
            <div class="section-heading">
                <div>
                    <div class="eyebrow"><span class="pulse-dot"></span> CHECKOUT &amp; DELIVERY</div>
                    <h2>Simple, flexible <span class="gradient-text">payments &amp; fast delivery.</span></h2>
                    <p>Doorstep Cash on Delivery, instant digital wallet checkout with 5% off, and nationwide express TCS delivery.</p>
                </div>
            </div>
            <div class="payment-methods">
                <div class="payment-card">
                    <div class="payment-badge">DOORSTEP</div>
                    <div class="payment-icon">💵</div>
                    <b>COD</b>
                    <span>Cash on Delivery</span>
                    <small>Pay with cash when your parcel arrives</small>
                </div>
                <div class="payment-card payment-discount-card">
                    <div class="payment-badge discount-badge">5% OFF</div>
                    <div class="payment-icon">📱</div>
                    <b>EP</b>
                    <span>Easypaisa Digital</span>
                    <small>Instant wallet payment · 5% auto discount</small>
                </div>
                <div class="payment-card payment-discount-card">
                    <div class="payment-badge discount-badge">5% OFF</div>
                    <div class="payment-icon">⚡</div>
                    <b>JC</b>
                    <span>JazzCash Mobile</span>
                    <small>Direct mobile transfer · 5% auto discount</small>
                </div>
                <div class="payment-card">
                    <div class="payment-badge">TRACKED</div>
                    <div class="payment-icon">📦</div>
                    <b>TCS</b>
                    <span>Courier Express</span>
                    <small>Verified nationwide courier delivery</small>
                </div>
                <div class="payment-card payment-fast-card">
                    <div class="payment-badge fast-badge">⚡ 24-48H</div>
                    <div class="payment-icon">🚀</div>
                    <b>FAST</b>
                    <span>Fast Delivery</span>
                    <small>Express 24–48 hours nationwide dispatch</small>
                </div>
            </div>
        </div>
    </section>
</main>

<footer class="pv-footer prestige-footer" id="contact">
    <div class="footer-topbar">
        <div class="container footer-topbar-inner">
            <a class="footer-top-logo" href="index.php" aria-label="WRISTVERSE home">
                <img src="assets/images/wristverse-wordmark.png?v=2" alt="WRISTVERSE">
            </a>
            <div class="footer-top-tagline">TIME BEYOND LIMITS</div>
        </div>
    </div>

    <div class="container footer-showcase">
        <div class="footer-panel footer-brand-panel">
            <div class="footer-heading">Brand</div>
            <a class="footer-brand-lockup" href="index.php">
                <img src="assets/images/wristverse-wordmark.png?v=2" alt="WRISTVERSE">
            </a>
            <div class="footer-brand-star">✦</div>
            <div class="footer-brand-copy">Premium watches</div>
            <div class="footer-brand-subcopy">Timeless style. Modern confidence.</div>
        </div>

        <div class="footer-panel footer-links-panel">
            <div class="footer-heading">Quick Links</div>
            <a class="footer-link-row" href="shop.php"><span class="footer-icon">◇</span><span>Shop Products</span></a>
            <a class="footer-link-row" href="cart.php"><span class="footer-icon">▱</span><span>Shopping Cart</span></a>
            <a class="footer-link-row" href="track-order.php"><span class="footer-icon">⌖</span><span>Track Order</span></a>
            <a class="footer-link-row" href="admin/login.php"><span class="footer-icon">◈</span><span>Admin Portal</span></a>
        </div>

        <div class="footer-panel footer-support-panel">
            <div class="footer-heading">Support</div>
            <a class="footer-support-row" href="mailto:supportwristversepk@gmail.com"><span class="footer-icon">✉</span><span><b>Email:</b> supportwristversepk@gmail.com</span></a>
            <a class="footer-whatsapp" href="https://wa.me/923273822228" target="_blank" rel="noopener"><span>◉</span> Chat Now</a>
            <div class="footer-support-row"><span class="footer-icon">▰</span><span><b>TCS Express</b> Nationwide delivery</span></div>
            <div class="footer-support-row footer-payment-note"><span class="footer-icon">◫</span><span>COD · Easypaisa · JazzCash</span></div>
        </div>
    </div>

    <div class="footer-bottombar">
        <div class="container">© <span id="yearSpan"></span> WRISTVERSE · Crafted for timeless style.</div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/store.js"></script>
<script>
document.addEventListener('DOMContentLoaded', async () => {
    await PV.ready;
    document.getElementById('yearSpan').textContent = new Date().getFullYear();

    // Check user session for nav
    const u = PV.getCurrentUser();
    if (u) {
        document.getElementById('navAuthSlot').innerHTML = `<a class="nav-link" href="account/index.php">My Account</a>`;
    }

    // Render Featured Products
    const products = PV.getProducts().slice(0, 6);
    const grid = document.getElementById('featuredGrid');

    if (products.length === 0) {
        grid.innerHTML = '<div class="col-12"><div class="empty-state">No products available.</div></div>';
        return;
    }

    grid.innerHTML = products.map(p => `
        <div class="col-12 col-sm-6 col-lg-4">
            <div class="product-card">
                <a class="product-art" href="product.php?id=${p.id}" aria-label="View ${p.name}">
                    <div class="art-glow"></div>
                    ${p.image ? `<img class="product-image" src="${p.image}" alt="${p.name}" loading="lazy">` : `
                        <div class="product-placeholder">
                            <span class="device-screen"></span>
                            <span class="device-port"></span>
                            <span class="device-bolt">ϟ</span>
                        </div>
                    `}
                    <span class="product-badge">WRISTVERSE</span>
                </a>
                <div class="product-info">
                    <div class="product-category">${p.category || 'TECH ACCESSORY'}</div>
                    <h3>${p.name}</h3>
                    <p>${p.description || 'Premium accessory.'}</p>
                    <div class="product-bottom">
                        <strong>${p.price ? PV.formatMoney(p.price) : 'Price not set'}</strong>
                        <a class="btn-mini" href="product.php?id=${p.id}">View ↗</a>
                    </div>
                    ${p.price && p.stock > 0 ? `
                        <button class="btn btn-neon w-100 mt-3" onclick="PV.addToCart(${p.id})">
                            Add to Cart
                        </button>
                    ` : `
                        <button class="btn btn-disabled w-100 mt-3" disabled>
                            ${p.stock <= 0 ? 'Out of Stock' : 'Unavailable'}
                        </button>
                    `}
                </div>
            </div>
        </div>
    `).join('');
});
</script>
</body>
</html>
