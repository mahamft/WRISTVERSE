/** WRISTVERSE storefront engine. MySQL is authoritative; localStorage is used only for cart/UI preferences. */
(function(){
'use strict';
const DEFAULT_SETTINGS={store_name:'WRISTVERSE.PK',support_email:'supportwristversepk@gmail.com',store_phone:'03273822228',whatsapp_number:'92327382228',easypaisa_number:'03273822228',jazzcash_number:'03074364067',shipping_charge:250,discount_percent:5};
const state={products:[],settings:{...DEFAULT_SETTINGS},orders:[],users:[],expenses:[],user:null,bootError:''};

function loadPhpClient(){
    if(window.WV_PHP)return Promise.resolve();
    return new Promise((resolve,reject)=>{
        const scripts=[...document.scripts]; const me=scripts.find(s=>(s.src||'').includes('/store.js'));
        const base=me?me.src.slice(0,me.src.lastIndexOf('/')+1):'assets/js/';
        const s=document.createElement('script');s.src=base+'php-client.js';s.onload=resolve;s.onerror=()=>reject(new Error('php-client.js failed to load'));document.head.appendChild(s);
    });
}
function numProduct(p){return {...p,id:Number(p.id),price:Number(p.price),cost_price:Number(p.cost_price),stock:Number(p.stock),featured:Number(p.featured),active:Number(p.active)};}
function normOrder(o){return {...o,id:Number(o.id||0),subtotal:Number(o.subtotal||0),discount:Number(o.discount||0),shipping:Number(o.shipping||0),total:Number(o.total||0),items:(o.items||[]).map(it=>({...it,order_item_id:Number(it.id||0),id:Number(it.product_id||it.id||0),product_id:Number(it.product_id||0),price:Number(it.price||0),qty:Number(it.qty||0),line:Number(it.line||0)}))};}
async function refreshRoleData(){
    state.orders=[];state.users=[];state.expenses=[];
    if(!state.user)return;
    if(state.user.role==='admin'){
        const [orders,users,expenses,products]=await Promise.all([WV_PHP.getOrders(),WV_PHP.getUsers(),WV_PHP.getExpenses(),WV_PHP.getProducts(true)]);
        state.orders=Array.isArray(orders)?orders.map(normOrder):[]; state.users=Array.isArray(users)?users:[]; state.expenses=Array.isArray(expenses)?expenses:[];
        if(Array.isArray(products))state.products=products.map(numProduct);
    }else{
        const orders=await WV_PHP.getMyOrders(); state.orders=Array.isArray(orders)?orders.map(normOrder):[];
    }
}
async function boot(){
    try{
        await loadPhpClient();
        const session=await WV_PHP.getSession();
        if(!session.success)throw new Error(session.error||'Session API unavailable');
        state.user=session.user||null;
        const [products,settings]=await Promise.all([WV_PHP.getProducts(false),WV_PHP.getSettings()]);
        if(!Array.isArray(products))throw new Error('Products could not be loaded from MySQL.');
        state.products=products.map(numProduct); if(settings&&typeof settings==='object')state.settings={...DEFAULT_SETTINGS,...settings};
        await refreshRoleData();
        window.dispatchEvent(new CustomEvent('wv:ready'));
        return true;
    }catch(e){state.bootError=e.message||String(e);console.error('[WRISTVERSE]',e);window.dispatchEvent(new CustomEvent('wv:error',{detail:state.bootError}));return false;}
}

const PV={
    ready:null,
    getBootError(){return state.bootError;},
    isPhpEnabled(){return !!window.WV_PHP;},
    async syncFromPhpBackend(){await this.ready;return this.refreshAll();},
    async refreshAll(){
        const products=await WV_PHP.getProducts(state.user?.role==='admin'); if(Array.isArray(products))state.products=products.map(numProduct);
        const settings=await WV_PHP.getSettings();if(settings)state.settings={...DEFAULT_SETTINGS,...settings};
        await refreshRoleData();return true;
    },
    getProducts(includeInactive=false){return includeInactive?state.products.slice():state.products.filter(p=>p.active===1);},
    getProduct(id){return state.products.find(p=>p.id===Number(id))||null;},
    async saveProduct(data,file=null){const r=await WV_PHP.saveProduct(data,file);if(!r.success)throw new Error(r.error||'Product save failed');const p=numProduct(r.data);const i=state.products.findIndex(x=>x.id===p.id);if(i>=0)state.products[i]=p;else state.products.unshift(p);return p;},
    async toggleProduct(id){const r=await WV_PHP.toggleProduct(id);if(!r.success)throw new Error(r.error||'Product status update failed');const p=state.products.find(x=>x.id===Number(id));if(p)p.active=p.active?0:1;return true;},
    async deleteProduct(id){const r=await WV_PHP.deleteProduct(id);if(!r.success)throw new Error(r.error||'Delete failed');state.products=state.products.filter(p=>p.id!==Number(id));return true;},
    getCart(){try{return JSON.parse(localStorage.getItem('PV_CART')||'{}');}catch(_){return{};}},
    addToCart(productId,qty=1){const cart=this.getCart(),p=this.getProduct(productId);if(!p||!p.active||p.stock<1){this.showToast('Product is currently out of stock.','error');return false;}cart[productId]=Math.min(p.stock,Number(cart[productId]||0)+Number(qty));localStorage.setItem('PV_CART',JSON.stringify(cart));this.updateNavCart();this.showToast(`Added "${p.name}" to cart!`);return true;},
    updateCart(productId,qty){const cart=this.getCart(),p=this.getProduct(productId);qty=Number(qty);if(qty<=0)delete cart[productId];else cart[productId]=Math.min(p?p.stock:99,qty);localStorage.setItem('PV_CART',JSON.stringify(cart));this.updateNavCart();},
    removeFromCart(productId){const cart=this.getCart();delete cart[productId];localStorage.setItem('PV_CART',JSON.stringify(cart));this.updateNavCart();this.showToast('Item removed from cart.');},
    getCartItems(){const cart=this.getCart();const items=[];let subtotal=0;for(const id in cart){const p=this.getProduct(id);if(p){const qty=Math.min(Number(cart[id]),p.stock);if(qty>0){const line=p.price*qty;subtotal+=line;items.push({...p,qty,line});}}}return{items,subtotal};},
    getCartCount(){return Object.values(this.getCart()).reduce((s,v)=>s+Number(v||0),0);},
    clearCart(){localStorage.setItem('PV_CART','{}');this.updateNavCart();},
    getOrders(){return state.orders.slice();},
    async placeOrder(orderData,proofFile=null){
        const safe={...orderData,items:(orderData.items||[]).map(i=>({id:i.id,qty:i.qty}))};
        delete safe.subtotal;delete safe.discount;delete safe.shipping;delete safe.total;delete safe.payment_proof;
        const r=await WV_PHP.placeOrder(safe,proofFile);if(!r.success)throw new Error(r.error||'Order could not be placed.');
        const order=normOrder(r.data);sessionStorage.setItem('PV_LAST_ORDER',JSON.stringify(order));if(state.user)state.orders.unshift(order);this.clearCart();
        const products=await WV_PHP.getProducts(state.user?.role==='admin');if(Array.isArray(products))state.products=products.map(numProduct);return order;
    },
    getLastOrder(){try{return JSON.parse(sessionStorage.getItem('PV_LAST_ORDER')||'null');}catch(_){return null;}},
    async updateOrderStatus(id,status,trackingNo='',trackingUrl=''){const r=await WV_PHP.updateOrderStatus(id,status,trackingNo,trackingUrl);if(!r.success)throw new Error(r.error||'Order update failed');const orders=await WV_PHP.getOrders();state.orders=Array.isArray(orders)?orders.map(normOrder):[];const products=await WV_PHP.getProducts(true);if(Array.isArray(products))state.products=products.map(numProduct);return true;},
    async trackOrder(code){const r=await WV_PHP.trackOrder(code);if(!r.success)return null;return normOrder(r.data);},
    getExpenses(){return state.expenses.slice();},
    async addExpense(label,amount,date){const r=await WV_PHP.addExpense(label,amount,date);if(!r.success)throw new Error(r.error||'Expense save failed');state.expenses.unshift(r.data);return r.data;},
    getSettings(){return {...state.settings};},
    async saveSettings(s){const merged={...state.settings,...s};const r=await WV_PHP.saveSettings(merged);if(!r.success)throw new Error(r.error||'Settings save failed');state.settings={...DEFAULT_SETTINGS,...(r.data||merged)};return state.settings;},
    getUsers(){return state.users.slice();},
    getCurrentUser(){return state.user?{...state.user}:null;},
    async login(email,password){const r=await WV_PHP.login(email,password);if(!r.success)return null;state.user=r.user;await refreshRoleData();return {...state.user};},
    async register(name,email,password){const r=await WV_PHP.register(name,email,password);if(!r.success)return{error:r.error||'Registration failed'};state.user=r.user;await refreshRoleData();return{user:{...state.user}};},
    async updateProfile(data){const r=await WV_PHP.updateProfile(data);if(!r.success)throw new Error(r.error||'Profile update failed');state.user=r.user;return {...state.user};},
    async changePassword(currentPassword,newPassword){const r=await WV_PHP.changePassword(currentPassword,newPassword);if(!r.success)throw new Error(r.error||'Password change failed');return true;},
    async logout(){try{await WV_PHP.logout();}finally{state.user=null;state.orders=[];state.users=[];state.expenses=[];sessionStorage.removeItem('PV_LAST_ORDER');}},
    formatMoney(amount){return 'Rs. '+Number(amount||0).toLocaleString('en-PK',{minimumFractionDigits:2,maximumFractionDigits:2});},
    showToast(message,type='success'){let c=document.getElementById('pvToastContainer');if(!c){c=document.createElement('div');c.id='pvToastContainer';c.style.cssText='position:fixed;bottom:24px;right:24px;z-index:99999;display:flex;flex-direction:column;gap:10px;pointer-events:none;';document.body.appendChild(c);}const t=document.createElement('div');t.style.cssText=`background:${type==='error'?'rgba(239,68,68,.95)':'rgba(15,23,34,.96)'};color:${type==='error'?'#fff':'#00e5ff'};border:1px solid ${type==='error'?'#ef4444':'rgba(0,229,255,.4)'};padding:12px 20px;border-radius:12px;font:14px system-ui;box-shadow:0 8px 30px rgba(0,0,0,.6);`;t.textContent=message;c.appendChild(t);setTimeout(()=>t.remove(),3500);},
    updateNavCart(){document.querySelectorAll('.cart-count').forEach(el=>el.textContent=this.getCartCount());}
};
window.PV=PV;PV.ready=boot();
document.addEventListener('DOMContentLoaded',()=>PV.updateNavCart());
})();
