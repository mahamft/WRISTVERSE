/** WRISTVERSE PHP/MySQL API client (same-origin XAMPP/cPanel). */
(function(){
'use strict';
function resolveApiBase(){
    const custom=localStorage.getItem('WV_PHP_API_URL');
    if(custom) return custom.replace(/\/+$/,'');
    const path=location.pathname;
    if(path.includes('/watches/admin/')||path.includes('/watches/account/')) return '../../backend/api';
    if(path.includes('/watches/')) return '../backend/api';
    return 'backend/api';
}
const API={
    csrfToken:'',
    getBaseUrl(){return resolveApiBase();},
    setBaseUrl(url){url?localStorage.setItem('WV_PHP_API_URL',url.trim()):localStorage.removeItem('WV_PHP_API_URL');},
    async request(endpoint,options={},retry=true){
        const method=(options.method||'GET').toUpperCase();
        let body=options.body;
        const headers={Accept:'application/json',...(options.headers||{})};
        if(body && !(body instanceof FormData) && typeof body==='object'){
            headers['Content-Type']='application/json'; body=JSON.stringify(body);
        }
        if(!['GET','HEAD','OPTIONS'].includes(method) && this.csrfToken) headers['X-CSRF-Token']=this.csrfToken;
        try{
            const res=await fetch(`${this.getBaseUrl()}/${endpoint}`,{...options,method,body,headers,credentials:'same-origin'});
            const text=await res.text();
            let json; try{json=JSON.parse(text);}catch(_){json={success:false,error:`Server returned invalid JSON (${res.status}).`};}
            if(json.csrf_token) this.csrfToken=json.csrf_token;
            if(res.status===419 && retry){await this.getSession();return this.request(endpoint,options,false);}
            if(!res.ok && json.success!==false) json.success=false;
            return json;
        }catch(err){return {success:false,error:'Cannot reach PHP backend: '+err.message};}
    },
    async getSession(){const r=await this.request('auth.php?action=me');if(r.csrf_token)this.csrfToken=r.csrf_token;return r;},
    async checkHealth(){const r=await this.request('products.php');return !!r.success;},
    async getProducts(all=false){const r=await this.request(`products.php${all?'?all=1':''}`);return r.success?r.data:null;},
    async getProduct(id){const r=await this.request(`products.php?id=${encodeURIComponent(id)}`);return r.success?r.data:null;},
    async saveProduct(data,file=null){
        let body=data;
        if(file){body=new FormData();Object.entries(data).forEach(([k,v])=>body.append(k,v??''));body.append('image_file',file);}
        return this.request('products.php',{method:'POST',body});
    },
    async toggleProduct(id){return this.request('products.php?action=toggle',{method:'POST',body:{id}});},
    async deleteProduct(id){return this.request(`products.php?id=${encodeURIComponent(id)}`,{method:'DELETE'});},
    async getOrders(){const r=await this.request('orders.php');return r.success?r.data:null;},
    async getMyOrders(){const r=await this.request('orders.php?mine=1');return r.success?r.data:null;},
    async trackOrder(code){return this.request(`orders.php?tracking=${encodeURIComponent(code)}`);},
    async placeOrder(data,proofFile=null){
        const form=new FormData();
        Object.entries(data).forEach(([k,v])=>{
            if(k==='items') form.append('items',JSON.stringify(v));
            else if(k!=='payment_proof') form.append(k,v??'');
        });
        if(proofFile)form.append('payment_proof',proofFile);
        return this.request('orders.php',{method:'POST',body:form});
    },
    async updateOrderStatus(id,status,trackingNo='',trackingUrl=''){return this.request('orders.php?action=status',{method:'POST',body:{id,status,tracking_number:trackingNo,tracking_url:trackingUrl}});},
    async login(email,password){const r=await this.request('auth.php?action=login',{method:'POST',body:{email,password}});if(r.csrf_token)this.csrfToken=r.csrf_token;return r;},
    async register(name,email,password){const r=await this.request('auth.php?action=register',{method:'POST',body:{name,email,password}});if(r.csrf_token)this.csrfToken=r.csrf_token;return r;},
    async updateProfile(data){return this.request('auth.php?action=profile',{method:'POST',body:data});},
    async changePassword(currentPassword,newPassword){return this.request('auth.php?action=change_password',{method:'POST',body:{current_password:currentPassword,new_password:newPassword}});},
    async logout(){return this.request('auth.php?action=logout',{method:'POST',keepalive:true});},
    async getUsers(){const r=await this.request('auth.php?action=users');return r.success?r.data:null;},
    async getSettings(){const r=await this.request('settings.php');return r.success?r.data:null;},
    async saveSettings(settings){return this.request('settings.php',{method:'POST',body:settings});},
    async getExpenses(){const r=await this.request('expenses.php');return r.success?r.data:null;},
    async addExpense(label,amount,date){return this.request('expenses.php',{method:'POST',body:{label,amount,expense_date:date}});}
};
window.WV_PHP=API;
})();
