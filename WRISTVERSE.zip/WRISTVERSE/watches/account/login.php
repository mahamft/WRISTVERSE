<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="../assets/images/wristverse-emblem.png">
    <title>Customer Login | WRISTVERSE</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="topline"></div>
<nav class="navbar navbar-expand-lg navbar-dark pv-nav sticky-top">
    <div class="container">
        <a class='navbar-brand brand brand-image' href='../index.php'><img src="../assets/images/wristverse-wordmark.png?v=2" alt="WRISTVERSE"></a>
        <div class="collapse navbar-collapse" id="pvNav">
            <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-3">
                <li class="nav-item"><a class='nav-link' href='../index.php'>Home</a></li>
                <li class="nav-item"><a class='nav-link' href='../shop.php'>Shop</a></li>
                <li class="nav-item"><a class='nav-link' href='../track-order.php'>Track Order</a></li>
                <li class="nav-item"><a class='nav-link' href='../contact.php'>Contact</a></li>
                <li class="nav-item">
                    <a class='nav-link cart-link' href='../cart.php'>
                        Cart <span class="cart-count">0</span>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<main>
    <section class="section-pad auth-bg">
        <div class="container auth-wrap">
            <form id="loginForm" class="form-panel auth-card">
                <div class="eyebrow">WELCOME BACK</div>
                <h1>Customer <span class="gradient-text">Log in</span></h1>
                <div id="errorBox" class="alert alert-danger d-none"></div>

                <label class="form-label" for="loginEmail">Email Address</label>
                <input class="form-control mb-3" id="loginEmail" type="email" required placeholder="name@example.com">

                <label class="form-label" for="loginPass">Password</label>
                <input class="form-control mb-4" id="loginPass" type="password" required>

                <button class="btn btn-neon w-100">Login to Account</button>
                <p class="muted mt-3">New customer? <a href='register.php'>Create an account</a></p>
                <p class="muted mt-2" style="font-size:11px;">Admin access? <a href='../admin/login.php'>Go to Admin Portal ↗</a></p>
            </form>
        </div>
    </section>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/store.js"></script>
<script>
(async () => {
    await PV.ready;
    const current = PV.getCurrentUser();
    if (current) { window.location.replace(current.role === 'admin' ? '../admin/index.php' : 'index.php'); return; }
    document.getElementById('loginForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        const err = document.getElementById('errorBox'); err.classList.add('d-none');
        const user = await PV.login(document.getElementById('loginEmail').value.trim(), document.getElementById('loginPass').value);
        if (user) window.location.replace(user.role === 'admin' ? '../admin/index.php' : 'index.php');
        else { err.textContent = 'Invalid email or password.'; err.classList.remove('d-none'); }
    });
})();
</script>
</body>
</html>
