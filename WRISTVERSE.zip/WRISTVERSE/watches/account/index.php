<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="../assets/images/wristverse-emblem.png">
    <title>My Account | WRISTVERSE</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .account-grid {
            display: grid;
            grid-template-columns: 280px 1fr;
            gap: 25px;
        }
        .user-card {
            border: 1px solid var(--line);
            border-radius: 14px;
            padding: 24px;
            background: linear-gradient(145deg, #081a2b, #040d17);
            text-align: center;
        }
        .avatar-circle {
            width: 74px;
            height: 74px;
            border-radius: 50%;
            border: 2px solid var(--cyan);
            background: rgba(0, 200, 255, 0.1);
            color: var(--cyan);
            font-size: 28px;
            font-weight: 800;
            display: grid;
            place-items: center;
            margin: 0 auto 16px;
            box-shadow: 0 0 20px rgba(0, 200, 255, 0.25);
        }
        .order-history-card {
            border: 1px solid var(--line);
            border-radius: 14px;
            background: linear-gradient(145deg, #081827, #030a12);
            padding: 20px;
            margin-bottom: 16px;
            transition: transform 0.2s ease, border-color 0.2s ease;
        }
        .order-history-card:hover {
            border-color: var(--cyan);
            transform: translateY(-2px);
        }
        .order-header-strip {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 12px;
            padding-bottom: 14px;
            border-bottom: 1px solid rgba(100, 170, 210, 0.15);
        }
        .order-history-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 0;
            border-bottom: 1px dashed rgba(100, 170, 210, 0.1);
            font-size: 13px;
        }
        .order-history-item:last-child {
            border-bottom: none;
        }
        .badge-status {
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 11px;
            font-weight: 600;
            letter-spacing: 0.05em;
        }
        .badge-status.delivered {
            background: rgba(34, 197, 94, 0.15);
            color: #4ade80;
            border: 1px solid rgba(34, 197, 94, 0.4);
        }
        .badge-status.processing, .badge-status.shipped, .badge-status.dispatched, .badge-status.confirmed {
            background: rgba(0, 200, 255, 0.15);
            color: var(--cyan);
            border: 1px solid rgba(0, 200, 255, 0.4);
        }
        .badge-status.pending {
            background: rgba(234, 179, 8, 0.15);
            color: #facc15;
            border: 1px solid rgba(234, 179, 8, 0.4);
        }
        .badge-status.cancelled {
            background: rgba(239, 68, 68, 0.15);
            color: #f87171;
            border: 1px solid rgba(239, 68, 68, 0.4);
        }
        @media (max-width: 991px) {
            .account-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
<div class="topline"></div>
<nav class="navbar navbar-expand-lg navbar-dark pv-nav sticky-top">
    <div class="container">
        <a class='navbar-brand brand brand-image' href='../index.php'><img src="../assets/images/wristverse-wordmark.png?v=2" alt="WRISTVERSE"></a>
        <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#pvNav" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="pvNav">
            <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-3">
                <li class="nav-item"><a class='nav-link' href='../index.php'>Home</a></li>
                <li class="nav-item"><a class='nav-link' href='../shop.php'>Shop</a></li>
                <li class="nav-item"><a class='nav-link' href='../track-order.php'>Track Order</a></li>
                <li class="nav-item"><a class='nav-link' href='../contact.php'>Contact</a></li>
                <li class="nav-item">
                    <a class='nav-link cart-link' href='../cart.php'>
                        Cart <span class="cart-count">0</span>
                    </a>
                </li>
                <li class="nav-item">
                    <a class='nav-link active' href='index.php'>My Account</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<main class="section-pad">
    <div class="container">
        <div class="account-grid">
            <!-- Left Sidebar Profile -->
            <aside>
                <div class="user-card mb-4">
                    <div class="avatar-circle" id="userAvatar">U</div>
                    <h3 id="userName" style="font-size:18px; margin-bottom:4px;">Customer Name</h3>
                    <p class="muted mb-2" id="userEmail" style="font-size:12px;">user@example.com</p>
                    <div class="mb-3">
                        <span class="status-pill" id="userRoleBadge">MEMBER</span>
                    </div>
                    <hr style="border-color:var(--line);">
                    <div class="d-grid gap-2">
                        <a href="../shop.php" class="btn btn-neon btn-sm">Explore Watches ↗</a>
                        <a href="../track-order.php" class="btn btn-outline-glow btn-sm">Track Package ⌁</a>
                        <button onclick="handleLogout()" class="btn btn-outline-glow btn-sm text-danger border-danger">Log Out ↪</button>
                    </div>
                </div>

                <div class="form-panel p-3">
                    <div class="eyebrow mb-2">QUICK SUPPORT</div>
                    <p style="font-size:11px; margin-bottom:10px;">Need help with an existing order or warranty query?</p>
                    <a href="https://wa.me/923273822228" target="_blank" rel="noopener" class="btn btn-sm btn-outline-glow w-100 mb-2">
                        WhatsApp 03273822228
                    </a>
                    <a href="mailto:supportwristversepk@gmail.com" class="btn btn-sm btn-outline-glow w-100">
                        Email Support
                    </a>
                </div>
            </aside>

            <!-- Right Content Area -->
            <div>
                <div class="section-heading mb-4">
                    <div>
                        <div class="eyebrow">DASHBOARD</div>
                        <h1>My <span class="gradient-text">Account</span></h1>
                        <p>View your past orders, active shipments, and delivery tracking details.</p>
                    </div>
                </div>

                <!-- Stats summary -->
                <div class="stats-grid mb-4">
                    <div class="stat-card">
                        <span>Total Orders</span>
                        <b id="myTotalOrders">0</b>
                        <small>Lifetime orders</small>
                    </div>
                    <div class="stat-card">
                        <span>Active Shipments</span>
                        <b id="myActiveOrders">0</b>
                        <small>In transit / processing</small>
                    </div>
                    <div class="stat-card">
                        <span>Total Spent</span>
                        <b id="myTotalSpent">Rs. 0.00</b>
                        <small>Delivered & confirmed</small>
                    </div>
                </div>

                <!-- Orders Section -->
                <div class="dashboard-panel mb-4">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h3 class="m-0">Recent Order History</h3>
                        <a href="../track-order.php" class="text-link">Live Tracker ↗</a>
                    </div>
                    <div id="ordersContainer">
                        <!-- Populated dynamically -->
                    </div>
                </div>

                <!-- Profile Update Card -->
                <div class="dashboard-panel">
                    <h3>Account Profile Information</h3>
                    <form id="profileForm" class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label" for="editName">Full Name</label>
                            <input class="form-control" id="editName" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label" for="editEmail">Email Address</label>
                            <input type="email" class="form-control" id="editEmail" disabled>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label" for="editPhone">Default Contact Phone</label>
                            <input class="form-control" id="editPhone" placeholder="03XXXXXXXXX">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label" for="editCity">City</label>
                            <input class="form-control" id="editCity" placeholder="e.g. Lahore, Karachi, Islamabad">
                        </div>
                        <div class="col-12">
                            <label class="form-label" for="editAddress">Default Shipping Address</label>
                            <textarea class="form-control" id="editAddress" rows="2" placeholder="Street, Sector, House #"></textarea>
                        </div>
                        <div class="col-12">
                            <button type="submit" class="btn btn-neon">Save Changes</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>

<footer class="pv-footer prestige-footer" id="contact">
    <div class="footer-topbar">
        <div class="container footer-topbar-inner">
            <a class="footer-top-logo" href="../index.php" aria-label="WRISTVERSE home">
                <img src="../assets/images/wristverse-wordmark.png?v=2" alt="WRISTVERSE">
            </a>
            <div class="footer-top-tagline">TIME BEYOND LIMITS</div>
        </div>
    </div>

    <div class="container footer-showcase">
        <div class="footer-panel footer-brand-panel">
            <div class="footer-heading">Brand</div>
            <a class="footer-brand-lockup" href="../index.php">
                <img src="../assets/images/wristverse-wordmark.png?v=2" alt="WRISTVERSE">
            </a>
            <div class="footer-brand-star">✦</div>
            <div class="footer-brand-copy">Premium watches</div>
            <div class="footer-brand-subcopy">Timeless style. Modern confidence.</div>
        </div>

        <div class="footer-panel footer-links-panel">
            <div class="footer-heading">Quick Links</div>
            <a class="footer-link-row" href="../shop.php"><span class="footer-icon">◇</span><span>Shop Products</span></a>
            <a class="footer-link-row" href="../cart.php"><span class="footer-icon">▱</span><span>Shopping Cart</span></a>
            <a class="footer-link-row" href="../track-order.php"><span class="footer-icon">⌖</span><span>Track Order</span></a>
            <a class="footer-link-row" href="../admin/login.php"><span class="footer-icon">◈</span><span>Admin Portal</span></a>
        </div>

        <div class="footer-panel footer-support-panel">
            <div class="footer-heading">Support</div>
            <a class="footer-support-row" href="mailto:supportwristversepk@gmail.com"><span class="footer-icon">✉</span><span><b>Email:</b> supportwristversepk@gmail.com</span></a>
            <a class="footer-whatsapp" href="https://wa.me/923273822228" target="_blank" rel="noopener"><span>◉</span> Chat Now</a>
            <div class="footer-support-row"><span class="footer-icon">▰</span><span><b>TCS Express</b> Nationwide delivery</span></div>
            <div class="footer-support-row footer-payment-note"><span class="footer-icon">◫</span><span>COD · Easypaisa · JazzCash</span></div>
        </div>
    </div>

    <div class="footer-bottombar">
        <div class="container">© <span id="yearSpan"></span> WRISTVERSE · Crafted for timeless style.</div>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/store.js"></script>
<script>
let currentUser = null;

async function handleLogout() {
    await PV.logout();
    window.location.replace('login.php');
}

document.addEventListener('DOMContentLoaded', async () => {
    await PV.ready;
    document.getElementById('yearSpan').textContent = new Date().getFullYear();

    currentUser = PV.getCurrentUser();
    if (!currentUser) {
        window.location.replace('login.php');
        return;
    }

    // Populate Sidebar
    document.getElementById('userName').textContent = currentUser.name || 'Valued Customer';
    document.getElementById('userEmail').textContent = currentUser.email || '';
    document.getElementById('userAvatar').textContent = (currentUser.name || 'U').charAt(0).toUpperCase();
    document.getElementById('userRoleBadge').textContent = (currentUser.role || 'customer').toUpperCase();

    // Populate Profile inputs
    document.getElementById('editName').value = currentUser.name || '';
    document.getElementById('editEmail').value = currentUser.email || '';
    document.getElementById('editPhone').value = currentUser.phone || '';
    document.getElementById('editCity').value = currentUser.city || '';
    document.getElementById('editAddress').value = currentUser.address || '';

    // Filter orders belonging to this user
    const allOrders = PV.getOrders();
    const userOrders = allOrders.filter(o => 
        (o.email && o.email.toLowerCase() === currentUser.email.toLowerCase()) ||
        (o.customer_name && o.customer_name.toLowerCase() === currentUser.name.toLowerCase()) ||
        (currentUser.phone && o.phone === currentUser.phone)
    );

    // Calculate stats
    const totalOrdersCount = userOrders.length;
    let activeOrdersCount = 0;
    let totalSpentAmount = 0;

    userOrders.forEach(o => {
        const s = (o.status || 'Pending').toLowerCase();
        if (s === 'pending' || s === 'processing' || s === 'shipped' || s === 'dispatched' || s === 'confirmed') {
            activeOrdersCount++;
        }
        totalSpentAmount += Number(o.total || 0);
    });

    document.getElementById('myTotalOrders').textContent = totalOrdersCount;
    document.getElementById('myActiveOrders').textContent = activeOrdersCount;
    document.getElementById('myTotalSpent').textContent = PV.formatMoney(totalSpentAmount);

    const ordersBox = document.getElementById('ordersContainer');

    if (userOrders.length === 0) {
        ordersBox.innerHTML = `
            <div class="empty-state py-4">
                <span style="font-size:32px;">🛍️</span>
                <h3 class="mt-2" style="font-size:18px;">No Orders Yet</h3>
                <p>You haven't placed any orders with WRISTVERSE yet.</p>
                <a href="../shop.php" class="btn btn-neon mt-2">Discover Smart Watches ↗</a>
            </div>
        `;
    } else {
        ordersBox.innerHTML = userOrders.map(order => {
            const statusClass = (order.status || 'pending').toLowerCase();
            return `
                <div class="order-history-card">
                    <div class="order-header-strip">
                        <div>
                            <span class="eyebrow" style="font-size:9px;">ORDER REF</span>
                            <strong style="color:var(--cyan); font-size:15px;">${order.order_number}</strong>
                            <div style="font-size:11px; color:var(--muted);">${order.created_at || 'Recently placed'}</div>
                        </div>
                        <div class="d-flex align-items-center gap-2">
                            <span class="badge-status ${statusClass}">${order.status || 'Pending'}</span>
                            <span class="badge-status" style="border:1px solid #64aad233; color:#91a9bd;">${(order.payment_method || 'cod').toUpperCase()}</span>
                        </div>
                    </div>

                    <div class="py-2">
                        ${(order.items || []).map(item => `
                            <div class="order-history-item">
                                <div>
                                    <span style="color:#fff;">${item.name}</span>
                                    <small class="muted d-block">Qty: ${item.qty} × ${PV.formatMoney(item.price)}</small>
                                </div>
                                <b>${PV.formatMoney(item.line || (item.price * item.qty))}</b>
                            </div>
                        `).join('')}
                    </div>

                    <div class="d-flex justify-content-between align-items-center pt-2 mt-2" style="border-top:1px solid rgba(100,170,210,0.15);">
                        <div>
                            ${order.tracking_number ? `
                                <span style="font-size:11px; color:var(--cyan);">
                                    🚚 TCS Tracking: <b>${order.tracking_number}</b>
                                </span>
                            ` : `
                                <span style="font-size:11px; color:var(--muted);">TCS Tracking will update once dispatched</span>
                            `}
                        </div>
                        <div class="d-flex align-items-center gap-3">
                            <div style="font-size:14px; color:#fff;">
                                Total: <strong style="color:var(--cyan);">${PV.formatMoney(order.total)}</strong>
                            </div>
                            <a href="../track-order.php?order=${order.order_number}" class="btn btn-mini btn-outline-glow">Track ↗</a>
                        </div>
                    </div>
                </div>
            `;
        }).join('');
    }

    // Save profile form
    document.getElementById('profileForm').addEventListener('submit', async (e) => {
        e.preventDefault();
        try {
            currentUser = await PV.updateProfile({
                name: document.getElementById('editName').value.trim(),
                phone: document.getElementById('editPhone').value.trim(),
                city: document.getElementById('editCity').value.trim(),
                address: document.getElementById('editAddress').value.trim()
            });
            document.getElementById('userName').textContent = currentUser.name;
            document.getElementById('userAvatar').textContent = currentUser.name.charAt(0).toUpperCase();
            PV.showToast('Profile updated successfully!');
        } catch (err) { PV.showToast(err.message, 'error'); }
    });
});
</script>
</body>
</html>
