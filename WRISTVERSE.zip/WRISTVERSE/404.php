<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="robots" content="noindex">
  <title>404 | WRISTVERSE</title>
  <style>
    body{margin:0;min-height:100vh;display:grid;place-items:center;background:#060504;color:#f5efe5;font-family:system-ui,-apple-system,Segoe UI,sans-serif}
    main{text-align:center;padding:32px}.code{font-size:clamp(64px,15vw,140px);font-weight:800;line-height:.9;color:#d7ad5b}
    h1{font-size:24px;margin:20px 0 8px}p{color:#bdb4a7;margin:0 0 24px}
    a{display:inline-block;color:#090807;background:#d7ad5b;padding:12px 20px;border-radius:999px;text-decoration:none;font-weight:700}
  </style>
</head>
<body>
  <main>
    <div class="code">404</div>
    <h1>Page not found</h1>
    <p>The page you requested does not exist.</p>
    <a href="./watches/">Back to WRISTVERSE</a>
  </main>
</body>
</html>
