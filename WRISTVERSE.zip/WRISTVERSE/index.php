<?php
// WRISTVERSE main entry point for XAMPP / Apache.
header('Location: watches/index.php');
exit;
